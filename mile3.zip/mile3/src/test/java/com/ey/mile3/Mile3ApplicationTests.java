package com.ey.mile3;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mile3ApplicationTests {

	public static void main(String[] args) {
		SpringApplication.run(Mile3ApplicationTests.class, args);
	}

}

