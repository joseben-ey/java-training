package com.ey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mile3Application {

	public static void main(String[] args) {
		SpringApplication.run(Mile3Application.class, args);
	}

}
